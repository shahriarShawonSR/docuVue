<?php if(!isset($no_padding)): ?>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Powered by <a href="http://dwijitsolutions.com">TMSS ICT LTD</a>
    </div>
    <strong>Copyright &copy; 2016-2018 <a href="http://honeycombhr.org/ict_doc/admin/pim-dashboard">TMSS ICT LTD</a>. </strong> All rights reserved.
</footer>
<?php endif; ?>

