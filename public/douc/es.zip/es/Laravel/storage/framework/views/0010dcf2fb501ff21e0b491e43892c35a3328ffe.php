<?php $__env->startSection("contentheader_title"); ?>
	<a href="<?php echo e(url(config('laraadmin.adminRoute') . '/document_manages')); ?>">Document Manage</a> :
<?php $__env->stopSection(); ?>
<?php $__env->startSection("contentheader_description", $document_manage->$view_col); ?>
<?php $__env->startSection("section", "Document Manages"); ?>
<?php $__env->startSection("section_url", url(config('laraadmin.adminRoute') . '/document_manages')); ?>
<?php $__env->startSection("sub_section", "Edit"); ?>

<?php $__env->startSection("htmlheader_title", "Document Manages Edit : ".$document_manage->$view_col); ?>

<?php $__env->startSection("main-content"); ?>

<?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="box">
	<div class="box-header">
		
	</div>
	<div class="box-body">
		<div class="row">
            <section class="content">
                <?php echo Form::model($document_manage, ['route' => [config('laraadmin.adminRoute') . '.document_manages.update', $document_manage->id ], 'method'=>'PUT', 'id' => 'document_manage-edit-form']); ?>

        <div class="panel panel-default" charset="UTF-8">
            <div class="panel-heading">
                <strong>Action Order Info</strong>
            </div>
            <div class="panel-body">
                <h4 class="text-success">
                                    </h4>  

                <div class="form-group row" charset="UTF-8">                    
                    <div class="col-md-12">
                        <!-- <label class="col-md-2 control-label"> Sarok No </label> -->
                        <div class="col-md-6">
                            <input class="form-control" placeholder="Enter enty by" required="1" name="enty_by" type="hidden" value="<?php echo e(Auth::user()->id); ?>" aria-required="true">
                           <?php echo LAFormMaker::input($module, 'sarok_no'); ?>
                        </div>                        
                        <div class="col-md-6" charset="UTF-8">
                         <?php echo LAFormMaker::input($module, 'project_title'); ?>
                        
                        </div>                        
                    </div>
                </div>            
               
                <div class="form-group row">                    
                    <div class="col-md-12">                        
                        <div class="col-md-6">                          
                           <?php echo LAFormMaker::input($module, 'others'); ?>
                        </div>

                        <div class="col-md-6" charset="UTF-8">
                            <?php echo LAFormMaker::input($module, 'project_sub_title'); ?>
                        </div>
                    </div>
                </div>

                <div class="form-group row">                    
                    <div class="col-md-12">                      
                          
                        <div class="col-md-6">
                         <?php echo LAFormMaker::input($module, 'issue_date'); ?>
                        </div>

                    </div>
                </div>

                <hr>            
                <strong> Additional Details </strong>
                <hr>

                <div class="form-group row">
                    <label class="control-label col-md-2">Image </label>
                    <div class="col-md-8">
                        <?php echo LAFormMaker::input($module, 'image'); ?>
                       
                    </div>
                
                </div>

                <div class="form-group row">
                
                    <div class="col-md-10">
                       <?php echo LAFormMaker::input($module, 'order_description'); ?>
                    </div>
                </div>                

            </div>
            <div class="panel-footer">
              
                    <div class="form-group">
                        <?php echo Form::submit( 'Update', ['class'=>'btn btn-success']); ?> <button class="btn btn-default pull-right"><a href="<?php echo e(url(config('laraadmin.adminRoute') . '/document_manages')); ?>">Cancel</a></button>
                    </div> 
            </div>
        </div>
           <?php echo Form::close(); ?>

</section>




			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(function () {
	$("#document_manage-edit-form").validate({
		
	});
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("la.layouts.app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>